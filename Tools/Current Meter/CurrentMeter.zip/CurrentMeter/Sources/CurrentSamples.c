// ***************************************************************************
//
//  Routines that handle Analog to Digital Samples from a power output.
//  A continuous series of ADC samples from a voltage source, convert the
//  samples to hexadecimal text, and send them on to the console UART.  The
//  samples are read by a DMA channel into an input buffer, converted to
//  hexadecminal text in an output buffer, and transfered to the console via
//  another DMA channel.
//
//  @file       $File$
//  @author     Emery Newlon
//  @version    $Revision$
//
// ***************************************************************************
//

#include <stddef.h>
#include <stdint.h>
#include "IO_Map.h"
#include "kinetis_hw.h"
#include "CurrentSamples.h"
#include "ADC_SAMPLER.h"
#include "ADC_SAMPLER_CLEAR.h"
#include "ADC_SAMPLER_RESTART.h"
#include "HEX_OUTPUT.h"
#include "MICROSECOND_COUNTER.h"
#include "SerialLink.h"
#include "SampleIO.h"

//  Timing in microseconds.

#define USEC_TIME_SIZE          8

static volatile uint32_t        usec_high  = 0 ;
static volatile uint32_t        usec_start = 0 ;
static volatile uint32_t        usec_last  = 0 ;

//  Table for looking up the hexadecimal text value used to index
//  the table entry.

extern const uint16_t           hex_byte_tbl [] ;

//  Control logging to the serial device.

static volatile int             adc_logging    = FALSE ;
static volatile int             turnon_logging = FALSE ;

//  Data Input information.

#define DATA_IN_SIZE            1

//  ADC Analog Reference Level calibration samples to average.

#define AREF_CALIB_COUNT        1024

//  ADC sample input buffer.  There are 16 bits per sample.

#define ADC_BUFFER_SIZE         64

volatile uint16_t               adc_input [ADC_BUFFER_SIZE * 2] ;
uint32_t                        adc_buffadd = ADC_BUFFER_SIZE ;

//  Hexadecimal output buffer.  There are 32 bits per sample.

const char                      tty_initstr [] =
                                "Current Measurement\r\n"
                                " use '+' key to start logging"
                                " '-' key to stop logging\r\n\n" ;

const uint32_t                  tty_initstr_size = sizeof (tty_initstr) - 1 ;

#define HEX_BUFFER_SIZE         (ADC_BUFFER_SIZE * ADC_SAMPLE_SIZE +        \
                                 ((ADC_BUFFER_SIZE - 1) / 16 + 1) + 1 +     \
                                 USEC_TIME_SIZE + DATA_IN_SIZE)

static volatile uint16_t        hex_output [HEX_BUFFER_SIZE] ;

//  DMA Channel that reads bits from the ADC device and places them into a
//  buffer.  Note:  This starts out as the SECOND DMA transfer to the buffer.
//  The first was initiated using the Processor Expert code.

uint32_t                        adcDMA_tcd [] =
{
    (uint32_t) (ADC_CH0 + ADC_REG_RA_OFF),
    (uint32_t) (adc_input + ADC_BUFFER_SIZE),
    (uint32_t) (ADC_BUFFER_SIZE * ADC_SAMPLE_SIZE),
    (uint32_t) (DMACTL_REG_CTL_ERQ          |
                DMACTL_REG_CTL_CS           | DMACTL_REG_CTL_S16        |
                DMACTL_REG_CTL_DINC         | DMACTL_REG_CTL_D16        |
                DMACTL_REG_CTL_SMOD_OFF     | DMACTL_REG_CTL_DMOD_OFF   |
                DMACTL_REG_CTL_LINKCC_DONE  | DMACTL_REG_CTL_LCH1_1     |
                DMACTL_REG_CTL_LCH2_0)
} ;

const uint32_t                  adcDMA_tcd_size = sizeof (adcDMA_tcd) ;

//  DMA Channel that clears the DMA Channel that reads the ADC device.

const uint32_t                  done_bit      = DMACTL_REG_STAT_DONE ;
const uint32_t                  done_bit_size = sizeof (done_bit) ;

static const uint32_t           clrDMA_tcd [] =
{
    (uint32_t) (& done_bit),
    (uint32_t) (DMACTL_CH0_TCD + DMACTL_REG_STATBC_OFF),
    (uint32_t) sizeof (done_bit),
    (uint32_t) (DMACTL_REG_CTL_S32          | DMACTL_REG_CTL_D32        |
                DMACTL_REG_CTL_SMOD_OFF     | DMACTL_REG_CTL_DMOD_OFF   |
                DMACTL_REG_CTL_LINKCC_DONE  | DMACTL_REG_CTL_LCH1_2     |
                DMACTL_REG_CTL_LCH2_0)
} ;

//  DMA Channel that resets the DMA Channel that reads the ADC device.

static const uint32_t           rstDMA_tcd [] =
{
    (uint32_t) (adcDMA_tcd),
    (uint32_t) (DMACTL_CH0_TCD),
    (uint32_t) sizeof (adcDMA_tcd),
    (uint32_t) (DMACTL_REG_CTL_EINT         |
                DMACTL_REG_CTL_SINC         | DMACTL_REG_CTL_S32        |
                DMACTL_REG_CTL_DINC         | DMACTL_REG_CTL_D32        |
                DMACTL_REG_CTL_SMOD_OFF     | DMACTL_REG_CTL_DMOD_OFF   |
                DMACTL_REG_CTL_LINKCC_NONE)
} ;

//  DMA Channel that transfers hex text to the serial port.

static uint32_t                 ttyDMA_tcd [] =
{
    (uint32_t) hex_output,
    (uint32_t) (UART0_CH0 + UART0_REG_D_OFF),
    (uint32_t) (HEX_BUFFER_SIZE * 2),
    (uint32_t) (DMACTL_REG_CTL_ERQ          |
                DMACTL_REG_CTL_CS           | DMACTL_REG_CTL_S8         |
                DMACTL_REG_CTL_SINC         | DMACTL_REG_CTL_D8         |
                DMACTL_REG_CTL_SMOD_OFF     | DMACTL_REG_CTL_DMOD_OFF   |
                DMACTL_REG_CTL_D_REQ        | DMACTL_REG_CTL_LINKCC_NONE)

} ;


// ***************************************************************************
//
//  Delay for a set number of microseconds.
//  Delays for the number of microseconds.
//
//  @param      millisecs   Number of microseconds to delay for.
//  @return     void
//
// ***************************************************************************
//

static void delay_us
(
    uint32_t        microseconds
)
{
    uint32_t        now ;
    uint32_t        target_time ;

    target_time = ((uint32_t) MICROSECOND_COUNTER_GetCounterValue (NULL) +
                   microseconds + 1) & 0xFFFF ;

    do
    {
        now = ((uint32_t) MICROSECOND_COUNTER_GetCounterValue (NULL))
              & 0xFFFF ;

        //  Continue until the target time is reached or passed.  Clock
        //  wrap around must be handled as well.

    } while (now < target_time ||
             (now > 0x8000 && target_time < 0x8000)) ;
}


// ***************************************************************************
//
//  Delay for a set number of milliseconds.
//  Delays for the number of milliseconds.
//
//  @param      millisecs   Number of milliseconds to delay for.
//  @return     void
//
// ***************************************************************************
//

static void delay_ms
(
    uint32_t        millisecs
)
{
    uint32_t        milli ;

    for (milli = 0 ; milli < millisecs ; milli ++)
    {
        delay_us (1000UL) ;
    }
}


// ***************************************************************************
//
//  ADC Calibration Routine
//  The ADC calibration routine is run just after the ADC is initialized.  It
//  calibrates the ADC so that its output is linear with its analog input
//  voltage.
//
//  @return     void
//
// ***************************************************************************
//

static void calibrateADC (void)
{
    uint32_t                calib ;

    //  Start the calibration operation and wait until it is done.

    ADC0_SC3 = (ADC_SC3_AVGE_MASK | ADC_SC3_AVGS (0x03)) |
               ADC_SC3_CAL_MASK ;

    while ((ADC0_SC1A & ADC_SC1_COCO_MASK) == 0)
        ;

    //  Calculate the calibration information and store it back in the ADC.

    calib = 0x8000 + (((ADC0_CLP4 & ADC_CLP4_CLP4_MASK) +
                       (ADC0_CLP3 & ADC_CLP3_CLP3_MASK) +
                       (ADC0_CLP2 & ADC_CLP2_CLP2_MASK) +
                       (ADC0_CLP1 & ADC_CLP1_CLP1_MASK) +
                       (ADC0_CLP0 & ADC_CLP0_CLP0_MASK) +
                       (ADC0_CLPS & ADC_CLPS_CLPS_MASK)) >> 1u) ;
    ADC0_PG = calib ;

    calib = 0x8000 + (((ADC0_CLM4 & ADC_CLM4_CLM4_MASK) +
                       (ADC0_CLM3 & ADC_CLM3_CLM3_MASK) +
                       (ADC0_CLM2 & ADC_CLM2_CLM2_MASK) +
                       (ADC0_CLM1 & ADC_CLM1_CLM1_MASK) +
                       (ADC0_CLM0 & ADC_CLM0_CLM0_MASK) +
                       (ADC0_CLMS & ADC_CLMS_CLMS_MASK)) >> 1u) ;
    ADC0_MG = calib ;

}   //  END calibrateADC


// ***************************************************************************
//
//  ADC startup routine
//  The ADC startup routine is run after ADC initialization.  It first
//  calibrates the ADC, then starts up ADC DMA, finally it starts continuous
//  ADC sampling.
//
//  @return     void
//
// ***************************************************************************
//

void startADC (void)
{
    LDD_TDeviceData     *   serial_dma ;
    LDD_TDeviceData     *   adc_dma ;
    LDD_TDeviceData     *   adc_clear_dma ;
    LDD_TDeviceData     *   adc_restart_dma ;
    LDD_TDeviceData     *   serial_dev ;
    char                    inchar ;

    //  Wait for the analog reference voltage to stablize.

    delay_ms (1000 * 5) ;

    //  Calibrate the ADC.

    calibrateADC () ;

    //  Initialize the serial port and activate DMA for its transmitter.

    serial_dma = HEX_OUTPUT_Init (NULL) ;
    (void) HEX_OUTPUT_AllocateChannel (serial_dma) ;
    (void) HEX_OUTPUT_EnableChannel (serial_dma) ;

    serial_dev = SerialLink_Init (NULL) ;

    UART0_C5 |= UART0_C5_TDMAE_MASK ;

    (void) SerialLink_Enable (serial_dev) ;

    //  Start the DMA operations for the ADC and sample output.

    adc_dma = ADC_SAMPLER_Init (NULL) ;
    (void) ADC_SAMPLER_AllocateChannel (adc_dma) ;
    (void) ADC_SAMPLER_EnableChannel   (adc_dma) ;

    adc_clear_dma = ADC_SAMPLER_CLEAR_Init (NULL) ;
    (void) ADC_SAMPLER_CLEAR_AllocateChannel (adc_clear_dma) ;
    (void) ADC_SAMPLER_CLEAR_EnableChannel   (adc_clear_dma) ;

    adc_restart_dma = ADC_SAMPLER_RESTART_Init (NULL) ;
    (void) ADC_SAMPLER_RESTART_AllocateChannel (adc_restart_dma) ;
    (void) ADC_SAMPLER_RESTART_EnableChannel   (adc_restart_dma) ;

    //  Start generating continuous ADC samples.

    ADC0_SC2 = ADC_SC2_DMAEN_MASK ;
    ADC0_SC3 = (ADC_SC3_AVGE_MASK | ADC_SC3_AVGS (0x03)) |
               ADC_SC3_CALF_MASK  | ADC_SC3_ADCO_MASK ;

    ADC0_SC1A = ADC_SC1_ADCH (0x00) | ADC_SC1_DIFF_MASK ;

    usec_start = (uint32_t) MICROSECOND_COUNTER_GetCounterValue (NULL) &
                            0xFFFFul ;

    //  Turn sample logging on and off based on characters received from the
    //  UART.

    while (1)
    {
        (void) SerialLink_ReceiveBlock (serial_dev, (LDD_TData *) & inchar, 1) ;

        do
        {
            SerialLink_Main (serial_dev) ;

        } while (SerialLink_GetReceivedDataNum (serial_dev) == 0) ;

        switch (inchar)
        {
            case '+'    :
            {
                turnon_logging = TRUE ;
                break ;
            }
            case '-'    :
            {
                turnon_logging = FALSE ;
                break ;
            }
            default     :
            {
                break ;
            }
        }
    }   //  WHILE (1)

}   // END startADC


// ***************************************************************************
//
//  ADC DMA buffer filled and restarted interrupt handler.
//  The ADC DMA Restart DMA transfer is re-initialized.  The ADC DMA Transfer
//  Control Descriptor is updated for the next half of the input buffer for
//  the next time the ADC DMA Restart is triggered.  Then the bytes in the
//  just received part of the buffer are processed.
//
//  @return     void
//
// ***************************************************************************
//

void currentSampleInt (void)
{
    uint32_t                now ;
    uint32_t                samptime_high ;
    uint32_t                samptime_low ;
    uint8_t                 sampctl_data ;
    volatile uint16_t   *   buffer ;
    volatile uint16_t   *   end_buffer ;
    int                     src ;
    int                     dst ;

    //  Get the buffer just filled and update it in the TCD, making it the
    //  next buffer to fill as well.  The buffer currently being filled by the
    //  DMA is the other buffer.

    adc_buffadd = - adc_buffadd ;

    buffer = (volatile uint16_t *)
             (adcDMA_tcd [DMACTL_REG_DSTADDR_OFF / sizeof (uint32_t)]) +
             adc_buffadd ;

    adcDMA_tcd [DMACTL_REG_DSTADDR_OFF / sizeof (uint32_t)] =
            (uint32_t) buffer ;

    //  Reinitialize the Clear and Restart DMA requests.

    * (volatile uint32_t *) (DMACTL_CH1_TCD + DMACTL_REG_STATBC_OFF) =
                                    done_bit ;

    for (src = 0 ;
            src < sizeof (clrDMA_tcd) / sizeof (clrDMA_tcd [0]) ;
         src ++)
    {
        ((volatile uint32_t *) DMACTL_CH1_TCD) [src] = clrDMA_tcd [src] ;
    }

    * (volatile uint32_t *) (DMACTL_CH2_TCD + DMACTL_REG_STATBC_OFF) =
                                    done_bit ;

    for (src = 0 ;
            src < sizeof (rstDMA_tcd) / sizeof (rstDMA_tcd [0]) ;
         src ++)
    {
        ((volatile uint32_t *) DMACTL_CH2_TCD) [src] = rstDMA_tcd [src] ;
    }

    //  Set the Sample Logging output according when sampling is turned on.
    //  All the following samples taken will be after (mostly) this output
    //  is set.

    if (turnon_logging != adc_logging)
    {
        SampleIO_SetFieldValue (NULL, DataOut00, turnon_logging) ;
    }

    //  Update the microsecond time every time counter wrap is detected.

    now = (uint32_t) MICROSECOND_COUNTER_GetCounterValue (NULL) & 0xFFFFul ;

    if (now < usec_last)
    {
        usec_high ++ ;
    }

    usec_last = now ;

    //  Log data to the serial port only when logging is enabled.

    if (adc_logging)
    {
        sampctl_data = (SampleIO_GetFieldValue (NULL, DataIn00) << 0) |
                       (SampleIO_GetFieldValue (NULL, DataIn11) << 1) |
                       (SampleIO_GetFieldValue (NULL, DataIn25) << 2) |
                       (SampleIO_GetFieldValue (NULL, DataIn67) << 6) ;

        //  Add the sample time in microseconds to the output.

        if (usec_start > now)
        {
            samptime_high = usec_high - 1 ;
            samptime_low  = now + 65536 - usec_start ;
        }
        else
        {
            samptime_high = usec_high ;
            samptime_low  = now - usec_start ;
        }

        dst = 0 ;

        hex_output [dst ++] = (((uint16_t) '>' ) << 0) +
                              (((uint16_t) ' ' ) << 8) ;
        hex_output [dst ++] = hex_byte_tbl [(samptime_high >> 24) & 0xFF] ;
        hex_output [dst ++] = hex_byte_tbl [(samptime_high >> 16) & 0xFF] ;
        hex_output [dst ++] = hex_byte_tbl [(samptime_high >>  8) & 0xFF] ;
        hex_output [dst ++] = hex_byte_tbl [(samptime_high >>  0) & 0xFF] ;
        hex_output [dst ++] = hex_byte_tbl [(samptime_low  >>  8) & 0xFF] ;
        hex_output [dst ++] = hex_byte_tbl [(samptime_low  >>  0) & 0xFF] ;
        hex_output [dst ++] = hex_byte_tbl [sampctl_data] ;
        hex_output [dst ++] = hex_byte_tbl [256] ;

        //  Convert the samples into hex text.  Add a new line every 64 bytes
        //  and a blank line at the end.

        end_buffer = buffer + ADC_BUFFER_SIZE ;

        for (src = 0 ; & buffer [src] < end_buffer ; src ++)
        {
            hex_output [dst ++] = hex_byte_tbl [(buffer [src] >> 8) & 0xFF] ;
            hex_output [dst ++] = hex_byte_tbl [(buffer [src] >> 0) & 0xFF] ;

            if ((src & 15) == 15)
            {
                hex_output [dst ++] = hex_byte_tbl [256] ;
            }
        }

        hex_output [dst ++] = hex_byte_tbl [256] ;

        //  Send the output to the com port via DMA.

        ttyDMA_tcd [DMACTL_REG_STATBC_OFF / sizeof (ttyDMA_tcd [0])] =
                        (uint32_t) dst * sizeof (hex_output [0]) ;

        * (volatile uint32_t *) (DMACTL_CH3_TCD + DMACTL_REG_STATBC_OFF) =
                                        done_bit ;

        for (src = 0 ;
                src < sizeof (ttyDMA_tcd) / sizeof (ttyDMA_tcd [0]) ;
             src ++)
        {
            ((volatile uint32_t *) DMACTL_CH3_TCD) [src] = ttyDMA_tcd [src] ;
        }
    }   //  IF (adc_logging)

    //  Turn of logging for the samples that were taken AFTER logging
    //  was activated.

    adc_logging = turnon_logging ;

}   //  END currentSampleInt
