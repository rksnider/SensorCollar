// ***************************************************************************
//
//  Hardware specific information.
//  Definitions of hardware specific information.
//
//  @file       $File$
//  @author     Emery Newlon
//  @version    $Revision$
//
// ***************************************************************************
//

#ifndef KINETIS_HW_H
#define KINETIS_HW_H

//  Base Addresses of various peripherals.

#define ADC_0_BASEADDR              0x4003B000u

#define DMAMUX_0_BASEADDR           0x40021000u

#define DMACTL_0_BASEADDR           0x40008100u

#define SPI_0_BASEADDR              0x40076000u

#define TPM_0_BASEADDR              0x40038000u

#define UART0_0_BASEADDR            0x4006A000u

//  Analog to Digital Converter registers and fields.

#define ADC_CH0                     (ADC_0_BASEADDR + 0x0000u)

#define ADC_REG_SC1A_OFF            0x00u
#define ADC_REG_SC1B_OFF            0x04u
#define ADC_REG_CFG1_OFF            0x08u
#define ADC_REG_CFG2_OFF            0x0Cu
#define ADC_REG_RA_OFF              0x10u
#define ADC_REG_RB_OFF              0x14u
#define ADC_REG_CV1_OFF             0x18u
#define ADC_REG_CV2_OFF             0x1Cu
#define ADC_REG_SC2_OFF             0x20u
#define ADC_REG_SC3_OFF             0x24u
#define ADC_REG_OFS_OFF             0x28u
#define ADC_REG_PG_OFF              0x2Cu
#define ADC_REG_MG_OFF              0x30u
#define ADC_REG_CLPD_OFF            0x34u
#define ADC_REG_CLPS_OFF            0x38u
#define ADC_REG_CLP4_OFF            0x3Cu
#define ADC_REG_CLP3_OFF            0x40u
#define ADC_REG_CLP2_OFF            0x44u
#define ADC_REG_CLP1_OFF            0x48u
#define ADC_REG_CLP0_OFF            0x4Cu
#define ADC_REG_CLMD_OFF            0x54u
#define ADC_REG_CLMS_OFF            0x58u
#define ADC_REG_CLM4_OFF            0x5Cu
#define ADC_REG_CLM3_OFF            0x60u
#define ADC_REG_CLM2_OFF            0x64u
#define ADC_REG_CLM1_OFF            0x68u
#define ADC_REG_CLM0_OFF            0x6Cu

//  DMA Multiplexer registers and fields.

#define DMAMUX_CONF_CH0             (DMAMUX_0_BASEADDR + 0)
#define DMAMUX_CONF_CH1             (DMAMUX_0_BASEADDR + 1)
#define DMAMUX_CONF_CH2             (DMAMUX_0_BASEADDR + 2)
#define DMAMUX_CONF_CH3             (DMAMUX_0_BASEADDR + 3)

#define DMAMUX_CONF_ENABLE          0x80u   //  DMA Channel connected to a device.
#define DMAMUX_CONF_TRIGGER         0x40u   //  DMA Triggered through PIT timer.
#define DMAMUX_CONF_SOURCE          0x3Fu   //  Source device channel connected to.

//  DMA requests routed through the DMA MUX.

#define DMAMUX_REQ_NONE             0x00u

#define DMAMUX_REQ_UART0_RCV        0x02u
#define DMAMUX_REQ_UART0_TRX        0x03u
#define DMAMUX_REQ_UART1_RCV        0x04u
#define DMAMUX_REQ_UART1_TRX        0x05u
#define DMAMUX_REQ_UART2_RCV        0x06u
#define DMAMUX_REQ_UART2_TRX        0x07u

#define DMAMUX_REQ_SPI0_RCV         0x10u
#define DMAMUX_REQ_SPI0_TRX         0x11u
#define DMAMUX_REQ_SPI1_RCV         0x12u
#define DMAMUX_REQ_SPI1_TRX         0x13u

#define DMAMUX_REQ_I2C0             0x16u
#define DMAMUX_REQ_I2C1             0x17u

#define DMAMUX_REQ_TPM0_0           0x18u
#define DMAMUX_REQ_TPM0_1           0x19u
#define DMAMUX_REQ_TPM0_2           0x1Au
#define DMAMUX_REQ_TPM0_3           0x1Bu
#define DMAMUX_REQ_TPM0_4           0x1Cu
#define DMAMUX_REQ_TPM0_5           0x1Du

#define DMAMUX_REQ_TPM1_0           0x20u
#define DMAMUX_REQ_TPM1_1           0x21u

#define DMAMUX_REQ_TPM2_0           0x22u
#define DMAMUX_REQ_TPM2_1           0x23u

#define DMAMUX_REQ_ADC0             0x28u

#define DMAMUX_REQ_CMP0             0x2Au

#define DMAMUX_REQ_DAC0             0x2Du

#define DMAMUX_REQ_PORT_A           0x31u
#define DMAMUX_REQ_PORT_D           0x34u

#define DMAMUX_REQ_TPM0_OVF         0x36u
#define DMAMUX_REQ_TPM1_OVF         0x37u
#define DMAMUX_REQ_TPM2_OVF         0x38u

#define DMAMUX_REQ_TSI              0x39u

#define DMAMUX_REQ_ALWAYSON_0       0x3Cu
#define DMAMUX_REQ_ALWAYSON_1       0x3Du
#define DMAMUX_REQ_ALWAYSON_2       0x3Eu
#define DMAMUX_REQ_ALWAYSON_3       0x3Fu

//  DMA Control registers and fields.  All the registers for a channel
//  are called its transfer control descriptor (TCD).  A TCD can be
//  copied to a channel's register set in address order to start a
//  transfer.

#define DMACTL_CH0_TCD              (DMACTL_0_BASEADDR +  0)
#define DMACTL_CH1_TCD              (DMACTL_0_BASEADDR + 16)
#define DMACTL_CH2_TCD              (DMACTL_0_BASEADDR + 32)
#define DMACTL_CH3_TCD              (DMACTL_0_BASEADDR + 48)

#define DMACTL_REG_SRCADDR_OFF       0u
#define DMACTL_REG_DSTADDR_OFF       4u
#define DMACTL_REG_STATBC_OFF        8u
#define DMACTL_REG_CONTROL_OFF      12u

#define DMACTL_REG_STAT_CE          0x40000000u     //  Config Error
#define DMACTL_REG_STAT_BES         0x20000000u     //  Bus Error on Source
#define DMACTL_REG_STAT_BED         0x10000000u     //  Bus Error on Dest
#define DMACTL_REG_STAT_REQ         0x04000000u     //  DMA Request is Pending
#define DMACTL_REG_STAT_BSY         0x02000000u     //  Busy with the transfer
#define DMACTL_REG_STAT_DONE        0x01000000u     //  Done with the transfer

#define DMACTL_REG_BYTECNT_PREF     0x00F00000u     //  Byte Count Prefix.
#define DMACTL_REG_BYTECNT          0x000FFFFFu     //  Number of bytes to transfer.

#define DMACTL_REG_CTL_EINT         0x80000000u     //  Enable Interrupt when done.
#define DMACTL_REG_CTL_ERQ          0x40000000u     //  Enable Peripheral request.
#define DMACTL_REG_CTL_CS           0x20000000u     //  Cycle steal.
#define DMACTL_REG_CTL_AA           0x10000000u     //  Auto-align.
#define DMACTL_REG_CTL_EADREQ       0x00800000u     //  Enable async DMA requests.

#define DMACTL_REG_CTL_SINC         0x00400000u     //  Increment the source addr.
#define DMACTL_REG_CTL_SSIZE        0x00300000u     //  Source size incr mask.
#define DMACTL_REG_CTL_S32          0x00000000u     //  Source size incr is 32 bits.
#define DMACTL_REG_CTL_S16          0x00200000u     //  Source size incr is 16 bits.
#define DMACTL_REG_CTL_S8           0x00100000u     //  Source size incr is  8 bits.

#define DMACTL_REG_CTL_DINC         0x00080000u     //  Increment the dest addr.
#define DMACTL_REG_CTL_DSIZE        0x00060000u     //  Dest size incr mask.
#define DMACTL_REG_CTL_D32          0x00000000u     //  Dest size incr is 32 bits.
#define DMACTL_REG_CTL_D16          0x00040000u     //  Dest size incr is 16 bits.
#define DMACTL_REG_CTL_D8           0x00020000u     //  Dest size incr is 8 bits.

#define DMACTL_REG_CTL_START        0x00010000u     //  Start the transfer.

#define DMACTL_REG_CTL_SMOD         0x0000F000u     //  Source modulo mask.
#define DMACTL_REG_CTL_SMOD_OFF     0x00000000u     //  No Source modulo.
#define DMACTL_REG_CTL_SMOD_16      0x00001000u     //  Modulo 16 * 2^n.

#define DMACTL_REG_CTL_DMOD         0x00000F00u     //  Dest modulo mask.
#define DMACTL_REG_CTL_DMOD_OFF     0x00000000u     //  No Dest modulo.
#define DMACTL_REG_CTL_DMOD_16      0x00000100u     //  Modulo 16 * 2^n.

#define DMACTL_REG_CTL_D_REQ        0x00000080u     //  Disable periph req when done.

#define DMACTL_REG_CTL_LINKCC       0x00000030u     //  Link channel mask.
#define DMACTL_REG_CTL_LINKCC_NONE  0x00000000u     //  No channel linking.
#define DMACTL_REG_CTL_LINKCC_CSD   0x00000010u     //  Link each cycle steal & done.
#define DMACTL_REG_CTL_LINKCC_CS    0x00000020u     //  Link each cycle steal.
#define DMACTL_REG_CTL_LINKCC_DONE  0x00000030u     //  Link when done.

#define DMACTL_REG_CTL_LCH1         0x0000000Cu     //  Link channel 1 mask.
#define DMACTL_REG_CTL_LCH1_0       0x00000000u     //  Link channel 1 is channel 0.
#define DMACTL_REG_CTL_LCH1_1       0x00000004u     //  Link channel 1 is channel 1.
#define DMACTL_REG_CTL_LCH1_2       0x00000008u     //  Link channel 1 is channel 2.
#define DMACTL_REG_CTL_LCH1_3       0x0000000Cu     //  Link channel 1 is channel 3.

#define DMACTL_REG_CTL_LCH2         0x00000003u     //  Link channel 2 mask.
#define DMACTL_REG_CTL_LCH2_0       0x00000000u     //  Link channel 2 is channel 0.
#define DMACTL_REG_CTL_LCH2_1       0x00000001u     //  Link channel 2 is channel 1.
#define DMACTL_REG_CTL_LCH2_2       0x00000002u     //  Link channel 2 is channel 2.
#define DMACTL_REG_CTL_LCH2_3       0x00000003u     //  Link channel 2 is channel 3.

//  Serial Peripheral Interface (SPI) registers and fields.

#define SPI_CH0                     (SPI_0_BASEADDR + 0x0000u)
#define SPI_CH1                     (SPI_0_BASEADDR + 0x1000u)

#define SPI_REG_C1_OFF              0u
#define SPI_REG_C2_OFF              1u
#define SPI_REG_BR_OFF              2u
#define SPI_REG_S_OFF               3u
#define SPI_REG_D_OFF               5u
#define SPI_REG_M_OFF               7u

#define SPI_REG_C1_SPIE             0x80u   //  Interrupt enable.
#define SPI_REG_C1_SPE              0x40u   //  SPI system enable.
#define SPI_REG_C1_SPTIE            0x20u   //  SPI transmit interrupt enable.
#define SPI_REG_C1_MSTR             0x10u   //  Master mode.
#define SPI_REG_C1_CPOL             0x08u   //  Clock polarity (active low).
#define SPI_REG_C1_CPHA             0x04u   //  Clock phase (cycle start).
#define SPI_REG_C1_SSOE             0x02u   //  Slave select output enable.
#define SPI_REG_C1_LSBFE            0x01u   //  LSB first (shifter direction).

#define SPI_REG_C2_SPMIE            0x80u   //  SPI match interrupt enable.
#define SPI_REG_C2_TXDMAE           0x20u   //  Transmit DMA enable.
#define SPI_REG_C2_MODFEN           0x10u   //  Master mode-fault function enable.
#define SPI_REG_C2_BIDIROE          0x08u   //  Bidirection mode output enable.
#define SPI_REG_C2_RXDMAE           0x04u   //  Receive DMA enable.
#define SPI_REG_C2_SPISWAI          0x02u   //  SPI stop in wait mode.
#define SPI_REG_C2_SPC0             0x01u   //  SPI pin control 0.

#define SPI_REG_BR_SPPR             0x30u   //  Baudrate prescaler divisor mask.
#define SPI_REG_BR_SPR              0x0Fu   //  Baudrate divisor mask.

#define SPI_REG_S_SPRF              0x80u   //  Read buffer full.
#define SPI_REG_S_SPMF              0x40u   //  Match.
#define SPI_REG_S_SPTEF             0x20u   //  Transmit buffer empty.
#define SPI_REG_S_MODF              0x10u   //  Master mode fault.

//  Timer Pulse Modulator registers and fields.

#define TPM0                        (TPM_0_BASEADDR + 0x0000u)
#define TPM1                        (TPM_0_BASEADDR + 0x1000u)
#define TPM2                        (TPM_0_BASEADDR + 0x2000u)

#define TPM_REG_SC_OFF              0x00u
#define TPM_REG_CNT_OFF             0x04u
#define TPM_REG_MOD_OFF             0x08u

#define TPM_REG_C0SC_OFF            0x0Cu
#define TPM_REG_C0V_OFF             0x10u
#define TPM_REG_C1SC_OFF            0x14u
#define TPM_REG_C1V_OFF             0x18u
#define TPM_REG_C2SC_OFF            0x1Cu
#define TPM_REG_C2V_OFF             0x20u
#define TPM_REG_C3SC_OFF            0x24u
#define TPM_REG_C3V_OFF             0x28u
#define TPM_REG_C4SC_OFF            0x2Cu
#define TPM_REG_C4V_OFF             0x30u
#define TPM_REG_C5SC_OFF            0x34u
#define TPM_REG_C5V_OFF             0x38u

#define TPM_REG_STATUS_OFF          0x50u
#define TPM_REG_CONF_OFF            0x84u

#define TPM_REG_SC_DMA              0x00000100u     //  DMA enable.
#define TPM_REG_SC_TOF              0x00000080u     //  Timer overflow flag.
#define TPM_REG_SC_TOIE             0x00000040u     //  Timer overflow interrupt enable.
#define TPM_REG_SC_CPWMS            0x00000020u     //  Center-aligned PWM select.

#define TPM_REG_SC_CMOD             0x00000018u     //  Clock mode selection mask.
#define TPM_REG_SC_CMOD_DIS         0x00000000u     //  Counter is disabled.
#define TPM_REG_SC_CMOD_INTCLK      0x00000008u     //  Use internal clock.
#define TPM_REG_SC_CMOD_EXTCLK      0x00000010u     //  Use external clock.

#define TPM_REG_SC_PS               0x00000007u     //  Prescale factor mask.
#define TPM_REG_SC_PS_DIV_1         0x00000000u     //  Divide by 1.
#define TPM_REG_SC_PS_DIV_2         0x00000001u     //  Divide by 2.
#define TPM_REG_SC_PS_DIV_4         0x00000002u     //  Divide by 4.
#define TPM_REG_SC_PS_DIV_8         0x00000003u     //  Divide by 8.
#define TPM_REG_SC_PS_DIV_16        0x00000004u     //  Divide by 16.
#define TPM_REG_SC_PS_DIV_32        0x00000005u     //  Divide by 32.
#define TPM_REG_SC_PS_DIV_64        0x00000006u     //  Divide by 64.
#define TPM_REG_SC_PS_DIV_128       0x00000007u     //  Divide by 128.

#define TPM_REG_CNT_COUNT           0x0000FFFFu     //  Counter value mask.

#define TPM_REG_MOD_MOD             0x0000FFFFu     //  Modulo value mask.

#define TPM_REG_CH_SC_CHF           0x00000080u     //  Channel flag.
#define TPM_REG_CH_SC_CHIE          0x00000040u     //  Channel interrupt enable.
#define TPM_REG_CH_SC_MSB           0x00000020u     //  Channel mode select B.
#define TPM_REG_CH_SC_MSA           0x00000010u     //  Channel mode select A.
#define TPM_REG_CH_SC_ELSB          0x00000008u     //  Edge or level select B.
#define TPM_REG_CH_SC_ELSA          0x00000004u     //  Edge or level select A.
#define TPM_REG_CH_SC_DMA           0x00000001u     //  DMA enable.

#define TPM_REG_CH_SC_DISABLE       0x00000000u     //  Channel disabled.
#define TPM_REG_CH_SC_SWCMP_1       0x00000010u     //  Software commpare.
#define TPM_REG_CH_SC_SWCMP_2       0x00000020u     //  Software commpare.
#define TPM_REG_CH_SC_SWCMP_3       0x00000030u     //  Software commpare.
#define TPM_REG_CH_SC_INRE          0x00000004u     //  Input capture on rising edge.
#define TPM_REG_CH_SC_INFE          0x00000008u     //  Input capture on falling edge.
#define TPM_REG_CH_SC_INBE          0x0000000Cu     //  Input capture on both edges.
#define TPM_REG_CH_SC_OUTTGL        0x00000014u     //  Output toggle on match.
#define TPM_REG_CH_SC_OUTCLR        0x00000018u     //  Output clear on match.
#define TPM_REG_CH_SC_OUTSET        0x0000001Cu     //  Output set on match.
#define TPM_REG_CH_SC_EPWMSET_1     0x00000024u     //  Output set on match.
#define TPM_REG_CH_SC_EPWMCLR       0x00000028u     //  Output clear on match.
#define TPM_REG_CH_SC_EPWMSET_2     0x0000002Cu     //  Output set on match.
#define TPM_REG_CH_SC_PULSESET_1    0x00000034u     //  Pulse output set on match.
#define TPM_REG_CH_SC_PULSECLR      0x00000038u     //  Pulse output clear on match.
#define TPM_REG_CH_SC_PULSESET_2    0x0000003Cu     //  Pulse output set on match.
#define TPM_REG_CH_SC_CPWMSET_1     0x00000024u     //  Set/clear on match up/down.
#define TPM_REG_CH_SC_CPWMCLR       0x00000028u     //  Clear/set on match up/down.
#define TPM_REG_CH_SC_CPWMSET_2     0x0000002Cu     //  Set/clear on match up/down.

#define TPM_REG_CH_V_VAL            0x0000FFFFu     //  Value mask.

#define TPM_REG_STATUS_TOF          0x00000100u     //  Timer overflow.
#define TPM_REG_STATUS_CH5F         0x00000020u     //  Channel 5 flag.
#define TPM_REG_STATUS_CH4F         0x00000010u     //  Channel 4 flag.
#define TPM_REG_STATUS_CH3F         0x00000008u     //  Channel 3 flag.
#define TPM_REG_STATUS_CH2F         0x00000004u     //  Channel 2 flag.
#define TPM_REG_STATUS_CH1F         0x00000002u     //  Channel 1 flag.
#define TPM_REG_STATUS_CH0F         0x00000001u     //  Channel 0 flag.

#define TPM_REG_CONF_TRGSEL         0x0F000000u     //  Trigger select mask.
#define TPM_REG_CONF_TRGSEL_EXT     0x00000000u     //  External triger pin input.
#define TPM_REG_CONF_TRGSEL_CMP0    0x01000000u     //  CMP0 output.
#define TPM_REG_CONF_TRGSEL_PIT0    0x04000000u     //  PIT trigger 0.
#define TPM_REG_CONF_TRGSEL_PIT1    0x05000000u     //  PIT trigger 1.
#define TPM_REG_CONF_TRGSEL_TPM0    0x08000000u     //  TPM0 overflow.
#define TPM_REG_CONF_TRGSEL_TPM1    0x09000000u     //  TPM1 overflow.
#define TPM_REG_CONF_TRGSEL_TPM2    0x0A000000u     //  TPM2 overflow.
#define TPM_REG_CONF_TRGSEL_RTCA    0x0C000000u     //  RTC alarm.
#define TPM_REG_CONF_TRGSEL_RTCS    0x0D000000u     //  RTC seconds.
#define TPM_REG_CONF_TRGSEL_LPTMR   0x0E000000u     //  LPTRM trigger.

#define TPM_REG_CONF_CROT           0x00040000u     //  Counter reload on trigger.
#define TPM_REG_CONF_CSOO           0x00020000u     //  Counter stop on overflow.
#define TPM_REG_CONF_CSOT           0x00010000u     //  Counter start on trigger.
#define TPM_REG_CONF_GTBEEN         0x00000200u     //  Global time base enable.

#define TPM_REG_CONF_DBGMODE        0x000000C0u     //  Debug mode mask.
#define TPM_REG_CONF_DBGMODE_OFF    0x00000000u     //  Counter pauses in debug mode.
#define TPM_REG_CONF_DBGMODE_ON     0x000000C0u     //  Counter continues in debug mode.

#define TPM_REG_CONF_DOZEEN_ON      0x00000000u     //  Counter continues in Doze mode.
#define TPM_REG_CONF_DOZEEN_OFF     0x00000020u     //  Counter pauses in Doze mode.

//  UART0 registers and fields.

#define UART0_CH0                   (UART0_0_BASEADDR + 0x0000u)

#define UART0_REG_BDH_OFF           0x00u
#define UART0_REG_BDL_OFF           0x01u
#define UART0_REG_C1_OFF            0x02u
#define UART0_REG_C2_OFF            0x03u
#define UART0_REG_S1_OFF            0x04u
#define UART0_REG_S2_OFF            0x05u
#define UART0_REG_C3_OFF            0x06u
#define UART0_REG_D_OFF             0x07u
#define UART0_REG_MA1_OFF           0x08u
#define UART0_REG_MA2_OFF           0x09u
#define UART0_REG_C4_OFF            0x0Au
#define UART0_REG_C5_OFF            0x0Bu




#endif  //  KINETIS_HW_H
