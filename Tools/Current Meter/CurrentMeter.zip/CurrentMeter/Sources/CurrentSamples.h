// ***************************************************************************
//
//  Current Sampling Definitions.
//  Constants and global declarations used for sampling analog voltages
//  to provide information to calculate the current with.
//
//  @file       $File$
//  @author     Emery Newlon
//  @version    $Revision$
//
// ***************************************************************************
//

#ifndef CURRENTSAMPLES_H
#define CURRENTSAMPLES_H

#include <stdint.h>

//  ADC sample buffer.

#define ADC_SAMPLE_SIZE         2

extern volatile uint16_t        adc_input [] ;
extern uint32_t                 adc_buffadd ;

//  Hexadecimal output buffer.

extern const char               tty_initstr [] ;
extern const uint32_t           tty_initstr_size ;

//  Main DMA TCD and done bit used to clear it.

extern uint32_t                 adcDMA_tcd [] ;
extern const uint32_t           adcDMA_tcd_size ;

extern const uint32_t           done_bit ;
extern const uint32_t           done_bit_size ;

//  ADC calibration and startup routine.

extern void startADC (void) ;

//  ADC Input Interrupt Handler.

extern void currentSampleInt (void) ;


#endif  //  CURRENTSAMPLES_H
