Thickness: 0.031in
Copper Weight: 1Oz
Finish: Lead Free
Board: FR4
Soldermask: Both sides
    Colour: Blue
Silkscreen: Both sides
    Colour: Yellow

Turn time: 1-2Weeks
Quantity: 10 or 20boards

Special Instructions:

Via in Pad requirements for all .005" and .007" holes.

Solder mask over the .005" holes on Layer 1 (but not over the pads on layer 6)