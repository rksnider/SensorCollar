Thickness: 0.062in
Copper Weight: 1Oz
Finish: Lead Free
Board: FR4
Soldermask: Both sides
    Colour: Blue
Silkscreen: Both sides
    Colour: Yellow

Turn time: 1-2Weeks
Quantity: 5-10boards

Special Instructions:

Via in Pad requirements for all .004" holes.